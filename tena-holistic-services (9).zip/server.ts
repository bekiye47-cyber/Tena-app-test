import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";

const DATA_FILE = path.join(process.cwd(), "leaderboard_data.json");

function loadLeaderboard(): any[] {
  try {
    if (fs.existsSync(DATA_FILE)) {
      const raw = fs.readFileSync(DATA_FILE, "utf-8");
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) {
        // Filter out any legacy mock data IDs (c1, c2, etc.)
        return parsed.filter(m => m && m.id && !m.id.match(/^c\d+$/));
      }
    }
  } catch (err) {
    console.error("Error reading leaderboard data file:", err);
  }
  return [];
}

function saveLeaderboard(data: any[]) {
  try {
    fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), "utf-8");
  } catch (err) {
    console.error("Error writing leaderboard data file:", err);
  }
}

let leaderboard = loadLeaderboard();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: "10mb" }));

  // CORS middleware for safety
  app.use((req, res, next) => {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
    if (req.method === "OPTIONS") {
      return res.sendStatus(200);
    }
    next();
  });

  // API Route: Health
  app.get("/api/health", (_req, res) => {
    res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
    res.json({ status: "ok", count: leaderboard.length });
  });

  // API Route: Get Leaderboard
  app.get("/api/leaderboard", (_req, res) => {
    res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
    res.json({
      success: true,
      members: leaderboard
    });
  });

  // API Route: Sync / Update User Score & Profile
  app.post("/api/leaderboard/sync", (req, res) => {
    try {
      res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
      const user = req.body;
      if (!user || (!user.id && !user.telegramId && !user.name)) {
        return res.status(400).json({ error: "Invalid user data" });
      }

      const uid = String(user.telegramId || user.id || "").trim();
      const uName = String(user.name || "Friend").replace(/\(You\)/i, "").trim();
      const rawUsername = user.username ? String(user.username).trim() : "";
      const uUsername = rawUsername.replace(/^@/, "").toLowerCase();

      const existingIndex = leaderboard.findIndex((m: any) => {
        if (uid && uid !== "guest" && String(m.telegramId || m.id) === uid) return true;
        if (uUsername && m.username && String(m.username).replace(/^@/, "").toLowerCase() === uUsername) return true;
        if (!uid || uid === "guest") {
          return m.name && m.name.toLowerCase() === uName.toLowerCase();
        }
        return false;
      });

      const updatedRecord = {
        id: uid || `user_${Date.now()}`,
        telegramId: uid || null,
        name: uName,
        username: uUsername || (existingIndex >= 0 ? leaderboard[existingIndex].username : ""),
        stars: typeof user.stars === "number" ? user.stars : (existingIndex >= 0 ? (leaderboard[existingIndex].stars || 0) : 0),
        dailyStars: typeof user.dailyStars === "number" ? user.dailyStars : (existingIndex >= 0 ? (leaderboard[existingIndex].dailyStars || 0) : 0),
        weeklyStars: typeof user.weeklyStars === "number" ? user.weeklyStars : (existingIndex >= 0 ? (leaderboard[existingIndex].weeklyStars || 0) : 0),
        avatar: user.avatar || (existingIndex >= 0 ? leaderboard[existingIndex].avatar : null),
        badge: user.badge || (existingIndex >= 0 ? leaderboard[existingIndex].badge : "Active Member"),
        lastActive: Date.now()
      };

      if (existingIndex >= 0) {
        leaderboard[existingIndex] = {
          ...leaderboard[existingIndex],
          ...updatedRecord
        };
      } else {
        leaderboard.unshift(updatedRecord);
      }

      saveLeaderboard(leaderboard);

      return res.json({
        success: true,
        member: updatedRecord,
        members: leaderboard
      });
    } catch (err: any) {
      console.error("Failed to sync leaderboard:", err);
      return res.status(500).json({ error: "Internal sync error" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
