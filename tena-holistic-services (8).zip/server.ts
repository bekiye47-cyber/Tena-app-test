import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";

const DATA_FILE = path.join(process.cwd(), "leaderboard_data.json");

const INITIAL_MEMBERS = [
  { id: "c1", telegramId: "c1", name: "Bonna T.", username: "bonna_t", stars: 2500, dailyStars: 85, weeklyStars: 420, avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80", badge: "🥇 Diamond Master", lastActive: Date.now() },
  { id: "c2", telegramId: "c2", name: "Prince K.", username: "prince_k", stars: 1900, dailyStars: 70, weeklyStars: 340, avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80", badge: "🥈 Gold III", lastActive: Date.now() },
  { id: "c3", telegramId: "c3", name: "Selma D.", username: "selma_d", stars: 1600, dailyStars: 65, weeklyStars: 280, avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&auto=format&fit=crop&q=80", badge: "🥉 Gold II", lastActive: Date.now() },
  { id: "c4", telegramId: "c4", name: "Luna Chen", username: "luna_c", stars: 1100, dailyStars: 50, weeklyStars: 210, avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=200&auto=format&fit=crop&q=80", badge: "Gold I", lastActive: Date.now() },
  { id: "c5", telegramId: "c5", name: "Dawit M.", username: "dawit_eth", stars: 920, dailyStars: 45, weeklyStars: 175, avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&auto=format&fit=crop&q=80", badge: "Gold I", lastActive: Date.now() },
  { id: "c6", telegramId: "c6", name: "Eva Khan", username: "eva_k", stars: 850, dailyStars: 40, weeklyStars: 160, avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=200&auto=format&fit=crop&q=80", badge: "Silver III", lastActive: Date.now() },
  { id: "c7", telegramId: "c7", name: "Beki", username: "bekiye41", stars: 780, dailyStars: 35, weeklyStars: 140, avatar: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=200&auto=format&fit=crop&q=80", badge: "Silver III", lastActive: Date.now() },
  { id: "c8", telegramId: "c8", name: "Munna Islam", username: "munna_i", stars: 710, dailyStars: 30, weeklyStars: 120, avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=200&auto=format&fit=crop&q=80", badge: "Silver II", lastActive: Date.now() },
  { id: "c9", telegramId: "c9", name: "Helen G.", username: "helen_g", stars: 620, dailyStars: 25, weeklyStars: 95, avatar: "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=200&auto=format&fit=crop&q=80", badge: "Silver I", lastActive: Date.now() },
  { id: "c10", telegramId: "c10", name: "Alex Rivers", username: "alex_r", stars: 550, dailyStars: 20, weeklyStars: 80, avatar: "https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=200&auto=format&fit=crop&q=80", badge: "Bronze III", lastActive: Date.now() },
  { id: "c11", telegramId: "c11", name: "Abel K.", username: "abel_k", stars: 390, dailyStars: 15, weeklyStars: 50, avatar: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=200&auto=format&fit=crop&q=80", badge: "Bronze II", lastActive: Date.now() },
  { id: "c12", telegramId: "c12", name: "Tigist W.", username: "tigist_w", stars: 240, dailyStars: 10, weeklyStars: 30, avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=200&auto=format&fit=crop&q=80", badge: "Bronze I", lastActive: Date.now() }
];

function loadLeaderboard(): any[] {
  try {
    if (fs.existsSync(DATA_FILE)) {
      const raw = fs.readFileSync(DATA_FILE, "utf-8");
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
  } catch (err) {
    console.error("Error reading leaderboard data file:", err);
  }
  return [...INITIAL_MEMBERS];
}

function saveLeaderboard(data: any[]) {
  try {
    fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), "utf-8");
  } catch (err) {
    console.error("Error writing leaderboard data file:", err);
  }
}

let leaderboard = loadLeaderboard();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: "10mb" }));

  // CORS middleware for safety
  app.use((req, res, next) => {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
    if (req.method === "OPTIONS") {
      return res.sendStatus(200);
    }
    next();
  });

  // API Route: Health
  app.get("/api/health", (_req, res) => {
    res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
    res.json({ status: "ok", count: leaderboard.length });
  });

  // API Route: Get Leaderboard
  app.get("/api/leaderboard", (_req, res) => {
    res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
    res.json({
      success: true,
      members: leaderboard
    });
  });

  // API Route: Sync / Update User Score & Profile
  app.post("/api/leaderboard/sync", (req, res) => {
    try {
      res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
      const user = req.body;
      if (!user || (!user.id && !user.telegramId && !user.name)) {
        return res.status(400).json({ error: "Invalid user data" });
      }

      const uid = String(user.telegramId || user.id || "").trim();
      const uName = String(user.name || "Friend").replace(/\(You\)/i, "").trim();
      const rawUsername = user.username ? String(user.username).trim() : "";
      const uUsername = rawUsername.replace(/^@/, "").toLowerCase();

      const existingIndex = leaderboard.findIndex((m: any) => {
        if (uid && uid !== "guest" && String(m.telegramId || m.id) === uid) return true;
        if (uUsername && m.username && String(m.username).replace(/^@/, "").toLowerCase() === uUsername) return true;
        if (!uid || uid === "guest") {
          return m.name && m.name.toLowerCase() === uName.toLowerCase();
        }
        return false;
      });

      const updatedRecord = {
        id: uid || `user_${Date.now()}`,
        telegramId: uid || null,
        name: uName,
        username: uUsername || (existingIndex >= 0 ? leaderboard[existingIndex].username : ""),
        stars: typeof user.stars === "number" ? user.stars : (existingIndex >= 0 ? (leaderboard[existingIndex].stars || 0) : 0),
        dailyStars: typeof user.dailyStars === "number" ? user.dailyStars : (existingIndex >= 0 ? (leaderboard[existingIndex].dailyStars || 0) : 0),
        weeklyStars: typeof user.weeklyStars === "number" ? user.weeklyStars : (existingIndex >= 0 ? (leaderboard[existingIndex].weeklyStars || 0) : 0),
        avatar: user.avatar || (existingIndex >= 0 ? leaderboard[existingIndex].avatar : null),
        badge: user.badge || (existingIndex >= 0 ? leaderboard[existingIndex].badge : "Active Member"),
        lastActive: Date.now()
      };

      if (existingIndex >= 0) {
        leaderboard[existingIndex] = {
          ...leaderboard[existingIndex],
          ...updatedRecord
        };
      } else {
        leaderboard.unshift(updatedRecord);
      }

      saveLeaderboard(leaderboard);

      return res.json({
        success: true,
        member: updatedRecord,
        members: leaderboard
      });
    } catch (err: any) {
      console.error("Failed to sync leaderboard:", err);
      return res.status(500).json({ error: "Internal sync error" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
